package org.akram.Ahorcado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringAhorcadoCasaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringAhorcadoCasaApplication.class, args);
	}

}
